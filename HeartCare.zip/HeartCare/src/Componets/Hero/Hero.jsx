import React from 'react'
import './Hero.css'
import arrow from '../../assets/arrow.png'  
import '../Modal/Modal.css'
import Modal from '../Modal/Modal.jsx'
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';

const Hero = () => {

    const [result, setResult] = React.useState("");
    const MySwal = withReactContent(Swal);
    //const formRef = useRef(null);

    
    
    const onSubmit = async (event) => {
      event.preventDefault();
      setResult("Sending....");
      const formData = new FormData(event.target);
       
      // Extract weight and height from the form data
      const weight = parseFloat(formData.get('weight'));
      const heightCm = parseFloat(formData.get('height'));
     
      // Validate weight and height
      if (isNaN(weight) || isNaN(heightCm) || heightCm <= 0) {
        setResult("Invalid weight or height.");
        
        return;
    }

     // Convert height from centimeters to meters
     const heightM = heightCm / 100;

      // Calculate BMI
      const bmi = weight / (heightM * heightM);
      // Append BMI to form data
      formData.append('bmi', bmi.toFixed(2));
     
      //form data to json
        
      setResult(formData);


      const formDataJson = {
        age: formData.get('age') || '',
        gender: formData.get('gender') || '',
        height: formData.get('height') || '',
        weight: formData.get('weight') || '',
        ap_hi: formData.get('blood_high') || '',
        ap_lo: formData.get('blood_low') || '',
        cholesterol: formData.get('cstorol') || '',
        gluc: formData.get('glucose') || '',
        alco: formData.get('alcohol') || '',
        smoke: formData.get('smoke') || '',
        active: formData.get('active') || '',
        bmi: formData.get('bmi') || ''
        // Add other fields as neededsmoke
    };
     //print json
    console.log('FormData JSON:', formDataJson);
  
 
  
      //const data = await response.json();
     // Send JSON data
// Send JSON data
    try {
    const response = await fetch("http://localhost:8000/predict", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"  // Set content type to application/json
        },
        body: JSON.stringify(formDataJson)  // Convert JSON object to string
    });
    if (!response.ok) {
        throw new Error(`Network response was not ok: ${response.statusText}`);
    }

    const data = await response.json();
    console.log("Response Data:", data);
    //setResult(`Form Submitted Successfully. Prediction: ${data.prediction}`);
    const predictionPercentage = (parseFloat(data.prediction) * 100).toFixed(2);
      if(parseFloat(data.prediction)>0.5)
      {
        MySwal.fire({
            title: 'Heart Care Alert-You are at Risk',
            text: 'You are at ' +predictionPercentage+ '%  risk of Heart Disease',
            icon: 'warning',
            iconColor: '#FF0000',
            confirmButtonText: 'Close'
        })
      }
      else{
        MySwal.fire({
            title: 'Heart Care Alert- You are Safe',
            text: 'You are at '+predictionPercentage+ ' % less risk of Heart Disease',
            icon: 'info',
            confirmButtonText: 'Close',
            iconColor: '#008000'
        });
      }
      if (formRef.current) {
        formRef.current.reset();
    }
} catch (error) {
    console.error('Error submitting form:', error);
    //setResult("An error occurred. Please try again.");
    //setResult(err)
    setResult(`An error occurred: ${error.message}`);
    //setResult(`An error occurred: ${response.statusText}`);


}

};









  return (
    <div class="hero">
    <div class="hero-text">
        <h1>Check Your Risk</h1>
        <form onSubmit={onSubmit} >
            <p>Age</p>
            <input type="text" name="age" placeholder="Enter Your Age" required />
            <p>Gender</p>
            <select name="gender" required>
                <option value="1">Man</option>
                <option value="0">Woman</option>
            </select>
            <p>Height</p>
            <input type="text" name="height" placeholder="Enter Your Height(cm)" required />
            <p>Weight</p>
            <input type="text" name="weight" placeholder="Enter Your Weight(Kg)" required />
            <p>Blood Pressure-High</p>
            <input type="text" name="blood_high" placeholder="Enter Your High Blood Pressure Level" required />
            <p>Low Pressure-High</p>
            <input type="text" name="blood_low" placeholder="Enter Your Low Blood Pressure Level" required />
            <p>Enter Your Cholesterol Level</p>
            <select name="cstorol" required>
                <option value="1">Low</option>
                <option value="2">Medium</option>
                <option value="3">High</option>
            </select>
            <p>Do you have blood Glucose?</p>
            <select name="glucose" required>
                <option value="0">No</option>
                <option value="1">Yes</option>
            </select>
            <p>Have you consumed alcoho? </p>
            <select name="alcohol" required>
                <option value="0">No</option>
                <option value="1">Yes</option>
            </select>
            <p>Have you Smoke? </p>
            <select name="smoke" required>
                <option value="0">No</option>
                <option value="1">Yes</option>
            </select>
            <p>Are you physically active? </p>
            <select name="active" required>
                <option value="0">No</option>
                <option value="1">Yes</option>
            </select>
            <button type="submit" class="btn">Check <img src={arrow} /></button>
        </form>
        </div>

</div>
  )
}

export default Hero
